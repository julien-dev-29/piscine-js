@extends('app')

@section('content')

<table>

</table>

@endsection